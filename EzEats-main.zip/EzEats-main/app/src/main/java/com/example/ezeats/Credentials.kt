package com.example.ezeats

//API Credentials. Replace hardcoded with .env file later.
//Also gotta deactivate and change these keys lmao
object Credentials {
    const val AWS_API_KEY = "AKIAQ3EGSOQJHU23DYSB"
    const val AWS_SECRET_KEY =  "vPbUjwyU+OB9pm212Q1snqT7hCN0Bl/eou5HZnrt"
    const val AWS_DYNAMO_DB_TABLE = "EzEatsUsers"
    const val GOOGLE_CSE_ID = "13f9e92f2347c46c6"
    const val GOOGLE_SEARCH_API_KEY = "AIzaSyBIY4Za1x9wIaWCoYhh0-x64TFAW-hOgCg"
}